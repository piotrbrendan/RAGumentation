# AWS::SageMaker::EndpointConfig ClarifyFeatureType<a name="aws-properties-sagemaker-endpointconfig-clarifyfeaturetype"></a>

<a name="aws-properties-sagemaker-endpointconfig-clarifyfeaturetype-description"></a>The `ClarifyFeatureType` property type specifies Property description not available\. for an [AWS::SageMaker::EndpointConfig](aws-resource-sagemaker-endpointconfig.md)\.