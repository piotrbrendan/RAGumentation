# AWS::SageMaker::EndpointConfig ClarifyHeader<a name="aws-properties-sagemaker-endpointconfig-clarifyheader"></a>

<a name="aws-properties-sagemaker-endpointconfig-clarifyheader-description"></a>The `ClarifyHeader` property type specifies Property description not available\. for an [AWS::SageMaker::EndpointConfig](aws-resource-sagemaker-endpointconfig.md)\.