# Common Data Formats for Built\-in Algorithms<a name="sagemaker-algo-common-data-formats"></a>

The following topics explain the data formats for the algorithms provided by Amazon SageMaker\.

**Topics**
+ [Common Data Formats for Training](cdf-training.md)
+ [Common Data Formats for Inference](cdf-inference.md)